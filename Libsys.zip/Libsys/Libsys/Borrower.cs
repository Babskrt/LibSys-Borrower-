﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Libsys
{
    public partial class Borrower : Form
    {
        private OleDbConnection con;
        public Borrower()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source= LibSys.mdb");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();

            OleDbCommand com = new OleDbCommand("Insert into borrower values ('" + txtID.Text + "', '" + txtName.Text + "', '" + DateTime.Parse(txtDate.Text) + "')", con);
            com.ExecuteNonQuery();

            MessageBox.Show("Successfully SAVE!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);

            con.Close();
            btnDelete.Focus();
            loadDatagrid();
        }

        private void loadDatagrid()
        {
            con.Open();

            OleDbCommand com = new OleDbCommand("Select * from Borrower ", con);
            com.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(com);
            DataTable tab = new DataTable();

            adap.Fill(tab);
            grid1.DataSource = tab;

            con.Close();
        }

        private void Borrower_Load(object sender, EventArgs e)
        {
            loadDatagrid();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            con.Open();
            int no = int.Parse(txtID.Text);

            OleDbCommand com = new OleDbCommand("Update borrower SET title= '" + txtName.Text + "', author='" +
                DateTime.Parse(txtDate.Text) + "' where userID= " + no, con);
            com.ExecuteNonQuery();

            MessageBox.Show("Successfully UPDATED!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);

            con.Close();
            loadDatagrid();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            int num = int.Parse(txtID.Text);

            DialogResult dr = MessageBox.Show("Are you sure you want to delete this?", "Confirm Deletion",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                OleDbCommand com = new OleDbCommand("Delete from borrower where userID = @num", con);
                com.Parameters.AddWithValue("@num", num);
                com.ExecuteNonQuery();

                MessageBox.Show("Successfully DELETED", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("CANCELLED!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            con.Close();
            loadDatagrid();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            con.Open();

            OleDbCommand com = new OleDbCommand("Select * from borrower where title like '%" + txtSearch.Text + "%'", con);
            com.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(com);
            DataTable tab = new DataTable();

            adap.Fill(tab);
            grid1.DataSource = tab;

            con.Close();
        }

        private void grid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = grid1.Rows[e.RowIndex].Cells["userID"].Value.ToString();
            txtName.Text = grid1.Rows[e.RowIndex].Cells["userName"].Value.ToString();
            txtDate.Text = grid1.Rows[e.RowIndex].Cells["dueDate"].Value.ToString();
        }
    }
}
